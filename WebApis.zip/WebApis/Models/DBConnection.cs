﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApis.Models
{
    public class DBConnection
    {
        public static string ConnectionString = "server=localhost;port=3306;database=examnewdb;user=root;password=";
    }
}
