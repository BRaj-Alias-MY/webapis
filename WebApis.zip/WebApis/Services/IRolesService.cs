﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApis.Models;

namespace WebApis.Services
{
   public interface IRolesService
    {

          Task<IEnumerable<Roles>> GetRoles();
           int  AddRole(Roles role);
          int UpdateRole(Roles role);
    }
}
