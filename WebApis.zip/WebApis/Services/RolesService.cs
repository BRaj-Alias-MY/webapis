﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MySql.Data.MySqlClient;
using System.Data;
using WebApis.Models;
using WebApis.Services;
namespace WebApis.Models
{
    internal class RolesService : IRolesService
    {
        public MySqlConnection con;
        public async Task<IEnumerable<Roles>> GetRoles()
        {
            using (var con = new MySqlConnection(DBConnection.ConnectionString))
            {
                await con.OpenAsync();
                return await con.QueryAsync<Roles>(
                  "select * from tbl_roles where roleId=1",
                  null,
                  commandType: CommandType.Text);
            }
        }
        public  int AddRole(Roles role)
        {
            MySqlConnection con = new MySqlConnection(DBConnection.ConnectionString);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("insert into tbl_roles(roleName) values(@roleName)", con);
            cmd.Parameters.AddWithValue("@roleName", role.roleName);
            if (cmd.ExecuteNonQuery() == 1)
                return 1;
            else
                return 0; 

        }
        public int UpdateRole(Roles role)
        {
            MySqlConnection con = new MySqlConnection(DBConnection.ConnectionString);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("update tbl_roles set roleName=@roleName where roleId=@roleId", con);
            cmd.Parameters.AddWithValue("@roleId",  Convert.ToInt32(role.roleId));
            cmd.Parameters.AddWithValue("@roleName", role.roleName);
            if (cmd.ExecuteNonQuery() == 1)
                return 1;
            else
                return 0;

        }


    }
}