﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApis.Models;
using WebApis.Services; 
namespace WebApis.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private IRolesService roleService;
        public RoleController(IRolesService roleService)
        {
            this.roleService = roleService;
        }
        [HttpGet]
        public async Task<IEnumerable<Roles>> Get()
        {
            return await this.roleService.GetRoles();
        }
        [HttpPost]
        [Route("insert")]
        public int  Post([FromBody]Roles role)
        {
           return   this.roleService.AddRole(role);
        }
    }
}